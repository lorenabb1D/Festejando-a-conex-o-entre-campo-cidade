let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["🥕", "🥦", "🚚", "🚜"];
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length;
let jogoAtivo = false;
let jogoFinalizado = false;

let somVitoria;

function preload() {
  soundFormats('mp3');
  somVitoria = loadSound('relaxing-guitar-loop-v5-245859 (1).mp3'); // ⬅️ adicione seu arquivo aqui
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  atualizaTela();
  desenhaInterface();
  desenhaLinhaDeChegada();
  desenhaJogadores();
  if (jogoAtivo && !jogoFinalizado) {
    verificaVencedor();
  }
}

function atualizaTela() {
  background(focused ? "brown" : "green");
}

function desenhaInterface() {
  if (!jogoAtivo) {
    mostraInstrucoes();
  } else if (jogoFinalizado) {
    mostraReinicio();
  }
}

function mostraInstrucoes() {
  fill("white");
  textSize(20);
  text("Clique na tela para começar a corrida", 15, 30);
  textSize(15);
  text("Use as teclas A, S, D, F para os jogadores correrem", 1, 45);
}

function mostraReinicio() {
  fill("white");
  textSize(20);
  text("Clique para reiniciar o jogo", 90, 360);
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 10, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function desenhaJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      exibeVencedor(i);
      jogoFinalizado = true;
      noLoop(); // Para o draw
    }
  }
}

function exibeVencedor(indice) {
  textSize(30);
  fill("black");
  text(jogador[indice] + " venceu!", 50, 200);
  if (!somVitoria.isPlaying()) {
    somVitoria.play();
  }
}

function keyReleased() {
  if (jogoAtivo && !jogoFinalizado) {
    movimentaJogador();
  }
}

function movimentaJogador() {
  for (let i = 0; i < quantidade; i++) {
    if (key === teclas[i]) {
      let distanciaAtual = xJogador[i];
      let ganho = map(distanciaAtual, 0, 350, 30, 10);
      xJogador[i] += random(ganho);
    }
  }
}

function mousePressed() {
  if (!jogoAtivo || jogoFinalizado) {
    reiniciaJogo();
  }
}

function reiniciaJogo() {
  for (let i = 0; i < quantidade; i++) {
    xJogador[i] = 0;
  }
  jogoAtivo = true;
  jogoFinalizado = false;
  loop(); // reinicia o draw
}
